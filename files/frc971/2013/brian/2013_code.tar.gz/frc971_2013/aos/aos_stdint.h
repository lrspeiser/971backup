#ifndef AOS_AOS_STDINT_H_
#define AOS_AOS_STDINT_H_

#include <stdint.h>

#ifdef __VXWORKS__
typedef int64_t intmax_t;
typedef uint64_t uintmax_t;
#endif

#endif

