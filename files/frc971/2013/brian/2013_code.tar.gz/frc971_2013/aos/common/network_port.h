#ifndef AOS_COMMON_NETWORK_PORT_H_
#define AOS_COMMON_NETWORK_PORT_H_

#include "aos/aos_stdint.h"

namespace aos {

// Constants representing the various ports used for communications and some
// documentation about what each is used for.
enum class NetworkPort : uint16_t {
  // UDP socket sending motor values from the atom to the crio.
  kMotors = 9710,
  // UDP socket forwarding drivers station packets from the crio to the atom.
  kDS = 9711,
  // UDP socket sending sensor values from the crio to the atom.
  kSensors = 9712,
  // TCP socket(s) (automatically reconnects) sending logs from the crio to the
  // atom.
  kLogs = 9713,
  // HTTP server that sends out camera feeds in mjpg format.
  // Should not be changed because this number shows up elsewhere too.
  kCameraStreamer = 9714,
};

// Constants representing the various devices that talk on the network and the
// last segment of their IP addresses.
enum class NetworkAddress : uint8_t {
  // The computer that the cRIO talks to.
  kAtom = 179,
  kCRIO = 2,
};

}  // namespace aos

#endif  // AOS_COMMON_NETWORK_PORT_H_
